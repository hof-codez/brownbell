import { useState, useEffect } from 'react';
import type { ReactNode } from 'react';
import { supabase } from '../lib/supabase';

interface PlayerLine {
    playerName: string;
    playerPosition: string;
    points: number;
    isSub?: boolean;
    subSource?: 'owner' | 'auto' | 'admin' | null;
    originalPlayerName?: string | null;
}

interface MatchupSummary {
    teamA: string;
    teamB: string;
    scoreA: number;
    scoreB: number;
    winner: string | null;
    tier: number | null;
    bonus: number;
    margin: number;
    playersA?: PlayerLine[];
    playersB?: PlayerLine[];
}

interface TopScorer {
    teamName: string;
    playerName: string;
    playerPosition: string;
    points: number;
}

interface StandingsRow {
    rank: number;
    teamName: string;
    combined: number;
    seasonTotal: number;
    bonusTotal: number;
    players?: PlayerLine[];
}

interface MainAwardRecap {
    matchupOfTheWeek: MatchupSummary | null;
    matchups: MatchupSummary[];
    biggestBlowout: MatchupSummary | null;
    topScorer: TopScorer | null;
    biggestUpset: {
        winner: string; loser: string; winnerProbability: number; scoreWinner: number; scoreLoser: number;
        winnerPlayers?: PlayerLine[]; loserPlayers?: PlayerLine[];
    } | null;
    leaguePredictions: {
        record: { correct: number; wrong: number };
        matchups: { teamA: string; teamB: string; percentA: number; percentB: number; winner: string | null; leagueCorrect: boolean | null }[];
    } | null;
    standingsTop3: StandingsRow[];
}

// Next Up and Season of Boom have no opponent, tier, bonus, or prediction
// mechanic at all - each is simply a standalone season-long point race
// per team, so these 5 categories replace the matchup-based ones Main
// Award gets.
interface SimpleAwardRecap {
    topScorer: TopScorer | null;
    criticalSub: { teamName: string; playerName: string; playerPosition: string; points: number; originalName: string; source: string } | null;
    bounceBack: { teamName: string; playerName: string; playerPosition: string; points: number; priorAverage: number } | null;
    coldStreak: { teamName: string; playerName: string; playerPosition: string; points: number; priorAverage: number } | null;
    positionalPowerhouse: { position: string; totalPoints: number } | null;
    standingsTop3: StandingsRow[];
}

interface RecapContent {
    week: number;
    main: MainAwardRecap;
    nextup: SimpleAwardRecap;
    boom: SimpleAwardRecap;
}

interface RecapPageProps {
    week: number;
}

const AWARD_TABS: { id: 'main' | 'nextup' | 'boom'; label: string }[] = [
    { id: 'main', label: 'Brown Bell' },
    { id: 'nextup', label: 'Next Up' },
    { id: 'boom', label: 'Season of Boom' }
];

// The standalone page rendered for a shared recap link
// (hof-codez.github.io/brownbell/#/recap/<week>) - no team claim, no tabs
// beyond the award selector below, no normal app shell. Deliberately its
// own self-contained component (rather than reusing ShowdownTab's
// matchup cards) since this reads a single static, already-computed JSON
// blob rather than any of the app's live hooks - the whole point of a
// shared link is that it never changes after the fact, so there's
// nothing here to keep in sync with live data at all.
export function RecapPage({ week }: RecapPageProps) {
    const [content, setContent] = useState<RecapContent | null>(null);
    const [loading, setLoading] = useState(true);
    const [notFound, setNotFound] = useState(false);
    const [activeAward, setActiveAward] = useState<'main' | 'nextup' | 'boom'>('main');

    useEffect(() => {
        let cancelled = false;

        async function load() {
            const { data, error } = await supabase
                .from('weekly_recaps')
                .select('content')
                .eq('week', week)
                .maybeSingle();

            if (cancelled) return;

            if (error || !data) {
                setNotFound(true);
            } else {
                setContent(data.content as RecapContent);
            }
            setLoading(false);
        }

        load();
        return () => { cancelled = true; };
    }, [week]);

    if (loading) {
        return (
            <div className="flex min-h-screen items-center justify-center bg-field">
                <p className="font-body text-sm text-chalk-dim">Loading&hellip;</p>
            </div>
        );
    }

    if (notFound || !content) {
        return (
            <div className="flex min-h-screen flex-col items-center justify-center gap-2 bg-field px-6 text-center">
                <p className="font-display text-2xl font-bold text-chalk">No recap for Week {week}</p>
                <p className="font-body text-sm text-chalk-dim">This week hasn&rsquo;t finished yet, or doesn&rsquo;t exist.</p>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-field px-4 py-8 text-chalk">
            <div className="mx-auto max-w-2xl">
                <header className="mb-6 text-center">
                    <p className="font-mono text-xs uppercase tracking-widest text-bell">Dynasty Side Awards</p>
                    <h1 className="mt-1 font-display text-4xl font-bold uppercase tracking-wide">
                        Brown Bell <span className="text-bell">&amp;</span> Next Up
                    </h1>
                    <p className="mt-1 font-body text-sm text-chalk-dim">Week {content.week} Recap</p>
                </header>

                <div className="mb-6 flex justify-center gap-1 rounded-lg border border-panel-line bg-panel p-1">
                    {AWARD_TABS.map(tab => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveAward(tab.id)}
                            className={`flex-1 rounded px-3 py-2 font-mono text-xs uppercase tracking-widest transition-colors ${
                                activeAward === tab.id ? 'bg-bell text-field' : 'text-chalk-dim'
                            }`}
                        >
                            {tab.label}
                        </button>
                    ))}
                </div>

                {activeAward === 'main' && <MainAwardSections recap={content.main} award="main" week={content.week} />}
                {activeAward === 'nextup' && <SimpleAwardSections recap={content.nextup} awardLabel="Next Up" award="nextup" />}
                {activeAward === 'boom' && <SimpleAwardSections recap={content.boom} awardLabel="Season of Boom" award="boom" />}
            </div>
        </div>
    );
}

function MainAwardSections({ recap, award, week }: { recap: MainAwardRecap; award: 'main' | 'nextup' | 'boom'; week: number }) {
    return (
        <>
            {recap.matchupOfTheWeek && (
                <Section title="Matchup of the Week" icon="⭐">
                    <MatchupCard m={recap.matchupOfTheWeek} highlight />
                </Section>
            )}

            <Section title="This Week's Matchups" icon="🏈">
                <div className="flex flex-col gap-2">
                    {recap.matchups.map((m, i) => (
                        <MatchupCard key={i} m={m} />
                    ))}
                </div>
            </Section>

            {recap.biggestBlowout && (
                <Section title="Biggest Blowout" icon="💥">
                    <MatchupCard m={recap.biggestBlowout} note={`${recap.biggestBlowout.margin.toFixed(1)} point margin`} />
                </Section>
            )}

            {recap.topScorer && (
                <Section title="Top Scorer" icon="🔥">
                    <TopScorerCard scorer={recap.topScorer} />
                </Section>
            )}

            {recap.biggestUpset && (
                <Section title="Biggest Upset" icon="⚡">
                    <div className="rounded-lg border border-panel-line bg-panel px-4 py-3">
                        <div className="flex items-start justify-between gap-3">
                            <div className="min-w-0">
                                <p className="font-body text-base font-bold text-chalk">{recap.biggestUpset.winner}</p>
                                <PlayerLines players={recap.biggestUpset.winnerPlayers} />
                            </div>
                            <p className="shrink-0 font-mono text-lg font-bold text-bell">
                                {recap.biggestUpset.scoreWinner.toFixed(1)}-{recap.biggestUpset.scoreLoser.toFixed(1)}
                            </p>
                        </div>
                        <div className="mt-2 border-t border-panel-line pt-2">
                            <p className="font-body text-sm text-chalk-dim">beat {recap.biggestUpset.loser}</p>
                            <PlayerLines players={recap.biggestUpset.loserPlayers} dim />
                        </div>
                        <p className="mt-2 font-mono text-xs text-chalk-dim">
                            Given only a {(recap.biggestUpset.winnerProbability * 100).toFixed(0)}% chance beforehand
                        </p>
                    </div>
                </Section>
            )}

            {recap.leaguePredictions && (
                <Section title="League Predictions" icon="🔮">
                    <div className="mb-2 rounded-lg border border-panel-line bg-panel px-4 py-3 text-center">
                        <p className="font-mono text-3xl font-bold text-bell">
                            {recap.leaguePredictions.record.correct}-{recap.leaguePredictions.record.wrong}
                        </p>
                        <p className="font-body text-xs text-chalk-dim">the league&rsquo;s record calling this week&rsquo;s matchups</p>
                    </div>
                    <div className="flex flex-col gap-1.5">
                        {recap.leaguePredictions.matchups.map((pm, i) => (
                            <div key={i} className="flex items-center justify-between rounded border border-panel-line bg-panel px-3 py-2 font-body text-xs">
                                <span className="text-chalk-dim">
                                    {pm.percentA >= pm.percentB ? pm.teamA : pm.teamB} favored {Math.max(pm.percentA, pm.percentB).toFixed(0)}%
                                </span>
                                {pm.leagueCorrect !== null && (
                                    <span className={`font-semibold ${pm.leagueCorrect ? 'text-bell' : 'text-brick'}`}>
                                        {pm.leagueCorrect ? 'Correct' : 'Wrong'}
                                    </span>
                                )}
                            </div>
                        ))}
                    </div>
                </Section>
            )}

            <StandingsSection standingsTop3={recap.standingsTop3} award={award} />

            <a
                href={`https://hof-codez.github.io/brownbell/#/predictions/${week + 1}`}
                className="mt-2 block rounded-lg border border-bell bg-bell/10 px-4 py-4 text-center"
            >
                <p className="font-body text-base font-bold text-chalk">🗳️ Vote on Week {week + 1}&rsquo;s Matchups</p>
                <p className="mt-0.5 font-mono text-xs uppercase tracking-widest text-bell">Cast your predictions &rarr;</p>
            </a>
        </>
    );
}

function SimpleAwardSections({ recap, awardLabel, award }: { recap: SimpleAwardRecap; awardLabel: string; award: 'main' | 'nextup' | 'boom' }) {
    return (
        <>
            {recap.topScorer ? (
                <Section title="Top Scorer" icon="🔥">
                    <TopScorerCard scorer={recap.topScorer} />
                </Section>
            ) : (
                <p className="mb-6 text-center font-body text-sm text-chalk-dim">No {awardLabel} scores recorded yet this week.</p>
            )}

            {recap.criticalSub && (
                <Section title="Critical Sub of the Week" icon="🔁">
                    <div className="rounded-lg border border-panel-line bg-panel px-4 py-3">
                        <p className="font-body text-sm text-chalk">
                            <span className="font-bold">{recap.criticalSub.playerName}</span> <span className="text-chalk-dim">({recap.criticalSub.playerPosition})</span> subbed in for {recap.criticalSub.originalName}
                        </p>
                        <p className="font-mono text-2xl font-bold text-bell">{recap.criticalSub.points.toFixed(1)} <span className="text-base font-normal text-chalk-dim">pts</span></p>
                        <p className="font-body text-xs text-chalk-dim">{recap.criticalSub.teamName} &middot; {recap.criticalSub.source === 'auto' ? 'auto-substituted' : recap.criticalSub.source}</p>
                    </div>
                </Section>
            )}

            {recap.bounceBack && (
                <Section title="Bounce Back" icon="📈">
                    <div className="rounded-lg border border-panel-line bg-panel px-4 py-3">
                        <p className="font-body text-sm font-bold text-chalk">
                            {recap.bounceBack.playerName} <span className="text-xs font-normal text-chalk-dim">({recap.bounceBack.playerPosition})</span>
                        </p>
                        <p className="font-mono text-2xl font-bold text-bell">{recap.bounceBack.points.toFixed(1)} <span className="text-base font-normal text-chalk-dim">pts</span></p>
                        <p className="font-body text-xs text-chalk-dim">{recap.bounceBack.teamName} &middot; up from a {recap.bounceBack.priorAverage.toFixed(1)} average</p>
                    </div>
                </Section>
            )}

            {recap.coldStreak && (
                <Section title="Cold Streak" icon="📉">
                    <div className="rounded-lg border border-panel-line bg-panel px-4 py-3">
                        <p className="font-body text-sm font-bold text-chalk">
                            {recap.coldStreak.playerName} <span className="text-xs font-normal text-chalk-dim">({recap.coldStreak.playerPosition})</span>
                        </p>
                        <p className="font-mono text-2xl font-bold text-brick">{recap.coldStreak.points.toFixed(1)} <span className="text-base font-normal text-chalk-dim">pts</span></p>
                        <p className="font-body text-xs text-chalk-dim">{recap.coldStreak.teamName} &middot; down from a {recap.coldStreak.priorAverage.toFixed(1)} average</p>
                    </div>
                </Section>
            )}

            {recap.positionalPowerhouse && (
                <Section title="Positional Powerhouse" icon="💪">
                    <div className="rounded-lg border border-panel-line bg-panel px-4 py-3 text-center">
                        <p className="font-mono text-3xl font-bold text-bell">{recap.positionalPowerhouse.position}</p>
                        <p className="font-body text-xs text-chalk-dim">combined for {recap.positionalPowerhouse.totalPoints.toFixed(1)} points league-wide this week</p>
                    </div>
                </Section>
            )}

            <StandingsSection standingsTop3={recap.standingsTop3} award={award} />
        </>
    );
}

function StandingsSection({ standingsTop3, award }: { standingsTop3: StandingsRow[]; award: 'main' | 'nextup' | 'boom' }) {
    if (standingsTop3.length === 0) return null;
    return (
        <Section title="Standings Snapshot" icon="🏆">
            <div className="flex flex-col gap-2">
                {standingsTop3.map(row => (
                    <div key={row.teamName} className="rounded-lg border border-panel-line bg-panel px-4 py-3">
                        <div className="flex items-start justify-between gap-3">
                            <div className="min-w-0">
                                <p className="font-body text-sm font-semibold text-chalk">
                                    <span className="mr-1.5 font-mono text-bell">#{row.rank}</span>
                                    {row.teamName}
                                </p>
                                <PlayerLines players={row.players} />
                            </div>
                            <p className="shrink-0 font-mono text-lg font-bold text-chalk">{row.combined.toFixed(1)}</p>
                        </div>
                    </div>
                ))}
            </div>
            <a
                href={`https://hof-codez.github.io/brownbell/#/league/${award}`}
                className="mt-2 block text-center font-mono text-xs uppercase tracking-widest text-bell underline"
            >
                View full standings &rarr;
            </a>
        </Section>
    );
}

function TopScorerCard({ scorer }: { scorer: TopScorer }) {
    return (
        <div className="rounded-lg border border-bell bg-bell/10 px-4 py-3">
            <p className="font-body text-lg font-bold text-chalk">
                {scorer.playerName} <span className="text-sm font-normal text-chalk-dim">({scorer.playerPosition})</span>
            </p>
            <p className="font-mono text-3xl font-bold text-bell">{scorer.points.toFixed(1)} <span className="text-base font-normal text-chalk-dim">pts</span></p>
            <p className="font-body text-xs text-chalk-dim">{scorer.teamName}</p>
        </div>
    );
}

function PlayerLines({ players, dim }: { players: PlayerLine[] | undefined; dim?: boolean }) {
    if (!players || players.length === 0) return null;
    return (
        <div className="mt-0.5 flex flex-col gap-0.5">
            {players.map((p, i) => (
                <div key={i} className={`font-mono text-xs ${dim ? 'text-chalk-dim' : 'text-chalk'}`}>
                    <p>
                        {p.playerName} <span className="text-chalk-dim">({p.playerPosition})</span> {p.points.toFixed(1)}
                        {p.isSub && (
                            <span className="ml-1.5 rounded bg-panel-line px-1 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-chalk-dim">
                                {p.subSource === 'auto' ? 'Auto-sub' : 'Sub'}
                            </span>
                        )}
                    </p>
                    {p.isSub && p.originalPlayerName && (
                        <p className="text-[10px] text-chalk-dim">for {p.originalPlayerName}</p>
                    )}
                </div>
            ))}
        </div>
    );
}

function Section({ title, icon, children }: { title: string; icon: string; children: ReactNode }) {
    return (
        <section className="mb-6">
            <h2 className="mb-2 flex items-center gap-1.5 font-mono text-xs uppercase tracking-widest text-chalk-dim">
                <span>{icon}</span> {title}
            </h2>
            {children}
        </section>
    );
}

function MatchupCard({ m, highlight, note }: { m: MatchupSummary; highlight?: boolean; note?: string }) {
    const aWon = m.winner === m.teamA;
    const bWon = m.winner === m.teamB;

    return (
        <div className={`rounded-lg border px-4 py-3 ${highlight ? 'border-bell bg-bell/10' : 'border-panel-line bg-panel'}`}>
            <div className="flex items-start justify-between gap-2">
                <div className="min-w-0 flex-1">
                    <p className={`truncate font-body text-sm font-bold ${aWon ? 'text-chalk' : 'text-chalk-dim'}`}>{m.teamA}</p>
                    <PlayerLines players={m.playersA} dim={!aWon} />
                    <p className={`mt-1 font-mono text-2xl font-bold ${aWon ? 'text-chalk' : 'text-chalk-dim'}`}>{m.scoreA.toFixed(1)}</p>
                </div>
                <span className="mt-1 shrink-0 font-mono text-xs text-chalk-dim">vs</span>
                <div className="min-w-0 flex-1 text-right">
                    <p className={`truncate font-body text-sm font-bold ${bWon ? 'text-chalk' : 'text-chalk-dim'}`}>{m.teamB}</p>
                    <div className="flex flex-col items-end">
                        <PlayerLines players={m.playersB} dim={!bWon} />
                    </div>
                    <p className={`mt-1 font-mono text-2xl font-bold ${bWon ? 'text-chalk' : 'text-chalk-dim'}`}>{m.scoreB.toFixed(1)}</p>
                </div>
            </div>
            {(m.tier || note) && (
                <p className="mt-2 border-t border-panel-line pt-2 font-mono text-xs text-chalk-dim">
                    {m.tier && `Tier ${m.tier} \u00b7 +${m.bonus.toFixed(2)} bonus`}
                    {m.tier && note && ' \u00b7 '}
                    {note}
                </p>
            )}
        </div>
    );
}
