// supabase-data-layer.js
// The automation's entire read/write boundary with Supabase. update-standings.js talks
// to this module only - it never touches the Supabase client directly, and never touches
// brown-bell-data.json. Internally, the automation's substitution/injury-detection logic
// still works with the same plain teamName-keyed objects it always has; this layer's job
// is translating that to and from the normalized Supabase tables.

const { createClient } = require('@supabase/supabase-js');

class SupabaseDataLayer {
    constructor() {
        const { SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY } = process.env;
        if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
            throw new Error('Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY env vars');
        }
        this.supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
        this.seasonId = null;
        this.teamIdByName = {};
        this.teamNameById = {};
    }

    // Call once per run before anything else. Loads (or fails loudly if missing) the
    // season row and the team-name <-> team-id mapping used everywhere below.
    async loadSeason(year, sleeperLeagueId) {
        const { data: season, error } = await this.supabase
            .from('seasons')
            .select('id, current_week, sleeper_league_id')
            .eq('year', year)
            .maybeSingle();

        if (error) throw new Error(`Failed to load season ${year}: ${error.message}`);
        if (!season) throw new Error(`No season row for ${year} - run seed-2026-season.js first`);

        this.seasonId = season.id;

        const { data: teams, error: teamsError } = await this.supabase
            .from('teams')
            .select('id, display_name, main_permanent_swap_used, nextup_permanent_swap_used, boom_permanent_swap_used')
            .eq('season_id', this.seasonId);

        if (teamsError) throw new Error(`Failed to load teams: ${teamsError.message}`);

        this.teamIdByName = {};
        this.teamNameById = {};
        this.teamSwapStateByName = {};
        for (const t of teams) {
            this.teamIdByName[t.display_name] = t.id;
            this.teamNameById[t.id] = t.display_name;
            // Independent per award - a permanent departure in one doesn't
            // touch the budget for the other two.
            this.teamSwapStateByName[t.display_name] = {
                main: t.main_permanent_swap_used,
                nextup: t.nextup_permanent_swap_used,
                boom: t.boom_permanent_swap_used
            };
        }

        return { seasonId: this.seasonId, currentWeek: season.current_week, sleeperLeagueId: season.sleeper_league_id };
    }

    // This award's own season-long swap budget for a team - read from the
    // cache loadSeason already populated, no extra round trip. Independent
    // of the other two awards' state for the same team.
    getTeamSwapState(teamName, awardType) {
        const state = this.teamSwapStateByName[teamName];
        return { permanentSwapUsed: state ? state[awardType] : false };
    }

    async updateTeamSwapState(teamName, awardType, permanentSwapUsed) {
        const teamId = this.teamIdByName[teamName];
        if (!teamId) throw new Error(`Unknown team: ${teamName}`);

        const column = awardType === 'nextup' ? 'nextup_permanent_swap_used'
            : awardType === 'boom' ? 'boom_permanent_swap_used'
            : 'main_permanent_swap_used';

        const { error } = await this.supabase
            .from('teams')
            .update({ [column]: permanentSwapUsed })
            .eq('id', teamId);

        if (error) throw new Error(`Failed to update ${awardType} swap state for ${teamName}: ${error.message}`);
        if (!this.teamSwapStateByName[teamName]) this.teamSwapStateByName[teamName] = { main: false, nextup: false, boom: false };
        this.teamSwapStateByName[teamName][awardType] = permanentSwapUsed;
    }

    async setCurrentWeek(week) {
        const { error } = await this.supabase
            .from('seasons')
            .update({ current_week: week })
            .eq('id', this.seasonId);
        if (error) throw new Error(`Failed to update current_week: ${error.message}`);
    }

    // Returns { main: { teamName: [ {name, position, experience?, sleeperId?}, ... ] }, nextup: {...} }
    // Teams with no duo rows yet simply don't appear - an owner hasn't set a lineup, so
    // that team doesn't participate in that award until they do. No placeholder needed.
    async loadKnownDuos() {
        const { data: duos, error } = await this.supabase
            .from('duos')
            .select('team_id, award_type, player_index, player_name, player_position, sleeper_player_id, experience')
            .in('team_id', Object.values(this.teamIdByName));

        if (error) throw new Error(`Failed to load duos: ${error.message}`);

        const knownDuos = { main: {}, nextup: {}, boom: {} };
        for (const d of duos) {
            const teamName = this.teamNameById[d.team_id];
            if (!teamName) continue;

            knownDuos[d.award_type][teamName] = knownDuos[d.award_type][teamName] || [null, null];
            knownDuos[d.award_type][teamName][d.player_index] = {
                name: d.player_name,
                position: d.player_position,
                sleeperId: d.sleeper_player_id || undefined,
                ...(d.experience ? { experience: d.experience } : {})
            };
        }

        // Drop any team left with a null slot (an incomplete duo isn't valid to run against)
        for (const awardType of ['main', 'nextup', 'boom']) {
            for (const [teamName, duo] of Object.entries(knownDuos[awardType])) {
                if (!duo[0] || !duo[1]) delete knownDuos[awardType][teamName];
            }
        }

        return knownDuos;
    }

    // Raw duo rows, ungrouped and including incomplete slots - used by the
    // automation's per-slot processing, which needs to see (and potentially
    // fill) an empty slot, not just complete pairs like loadKnownDuos() returns.
    async loadDuoRows() {
        const { data, error } = await this.supabase
            .from('duos')
            .select('id, team_id, award_type, player_index, player_name, player_position, sleeper_player_id, source, original_sleeper_player_id, player_departed')
            .in('team_id', Object.values(this.teamIdByName));

        if (error) throw new Error(`Failed to load duo rows: ${error.message}`);

        return data.map(row => ({
            rowId: row.id,
            teamName: this.teamNameById[row.team_id],
            awardType: row.award_type,
            playerIndex: row.player_index,
            playerName: row.player_name,
            playerPosition: row.player_position,
            sleeperPlayerId: row.sleeper_player_id,
            source: row.source,
            originalSleeperPlayerId: row.original_sleeper_player_id,
            playerDeparted: row.player_departed || false
        })).filter(row => row.teamName); // drop rows for a team not in this season's roster
    }

    // Batch-updates injury_status for every currently-set duo slot, called once
    // per automation run - purely a display field, never read by any
    // substitution/scoring logic (that always reads live Sleeper data directly).
    async updateDuoInjuryStatuses(updates) {
        if (!updates || updates.length === 0) return;

        const results = await Promise.all(updates.map(({ rowId, injuryStatus }) =>
            this.supabase.from('duos').update({ injury_status: injuryStatus }).eq('id', rowId)
        ));

        const failed = results.find(r => r.error);
        if (failed) console.error(`Failed to update some duo injury statuses (non-fatal): ${failed.error.message}`);
    }

    // Batch-updates player_departed for pre-lock duo slots specifically -
    // see 027-duo-player-departed.sql. A locked slot's departure is
    // already actively resolved (cleared/auto-filled) elsewhere and never
    // needs this flag set true.
    async updateDuoDepartedFlags(updates) {
        if (!updates || updates.length === 0) return;

        const results = await Promise.all(updates.map(({ rowId, departed }) =>
            this.supabase.from('duos').update({ player_departed: departed }).eq('id', rowId)
        ));

        const failed = results.find(r => r.error);
        if (failed) console.error(`Failed to update some duo departed flags (non-fatal): ${failed.error.message}`);
    }

    // Direct write to duos - the automation's own auto-fill/lock-freeze/revert
    // path. Owner-driven writes go through set-duo (the Edge Function), not here.
    // One-time-per-row catch-up for duos rows written before player_team
    // existed. Ordinary operation only ever writes player_team through
    // upsertDuoSlot, which only fires on an actual change (injury,
    // departure, revert) - a healthy, untouched pick from before this
    // column existed would otherwise never get it populated, no matter
    // how many times the automation runs. Cheap after the first pass:
    // once every existing row has a value, this query returns nothing and
    // the loop below never executes.
    async backfillPlayerTeams() {
        const { data: rows, error } = await this.supabase
            .from('duos')
            .select('id, sleeper_player_id')
            .is('player_team', null)
            .not('sleeper_player_id', 'is', null);

        if (error) {
            console.error('Failed to query duos for player_team backfill:', error.message);
            return;
        }
        if (!rows || rows.length === 0) return;

        console.log(`Backfilling player_team for ${rows.length} existing duo slot(s)...`);
        for (const row of rows) {
            const team = this.playersData?.[row.sleeper_player_id]?.team || null;
            if (!team) continue; // can't resolve it here either - leave it for a future pass
            const { error: updateError } = await this.supabase
                .from('duos')
                .update({ player_team: team })
                .eq('id', row.id);
            if (updateError) {
                console.error(`Failed to backfill player_team for duo row ${row.id}:`, updateError.message);
            }
        }
    }

    async upsertDuoSlot({ teamName, awardType, playerIndex, playerName, playerPosition, sleeperPlayerId, source, originalSleeperPlayerId }) {
        const teamId = this.teamIdByName[teamName];
        if (!teamId) throw new Error(`Unknown team: ${teamName}`);

        const row = {
            team_id: teamId,
            award_type: awardType,
            player_index: playerIndex,
            player_name: playerName,
            player_position: playerPosition,
            sleeper_player_id: sleeperPlayerId,
            // Current NFL team, so the frontend can show "next game" info
            // without a separate player lookup - resolved from the shared
            // playersData reference the automator sets after loading
            // players (see initializeLeagueData), not passed in by each
            // caller individually.
            player_team: sleeperPlayerId ? (this.playersData?.[sleeperPlayerId]?.team || null) : null,
            source
        };
        if (originalSleeperPlayerId !== undefined) row.original_sleeper_player_id = originalSleeperPlayerId;

        const { error } = await this.supabase
            .from('duos')
            .upsert(row, { onConflict: 'team_id,award_type,player_index' });

        if (error) throw new Error(`Failed to upsert duo slot for ${teamName}/${awardType}/${playerIndex}: ${error.message}`);
    }

    // Stamps original_sleeper_player_id without touching anything else - the
    // one-time freeze that happens the moment a slot's occupant locks in.
    async freezeOriginalPlayer(rowId, sleeperPlayerId) {
        const { error } = await this.supabase
            .from('duos')
            .update({ original_sleeper_player_id: sleeperPlayerId })
            .eq('id', rowId);
        if (error) throw new Error(`Failed to freeze original player: ${error.message}`);
    }

    // Leaves a slot genuinely empty - the "1st permanent departure, awaiting
    // owner pick" case. The frontend already renders a missing row as "Not set yet".
    async clearDuoSlot(teamName, awardType, playerIndex) {
        const teamId = this.teamIdByName[teamName];
        if (!teamId) throw new Error(`Unknown team: ${teamName}`);

        const { error } = await this.supabase
            .from('duos')
            .delete()
            .eq('team_id', teamId)
            .eq('award_type', awardType)
            .eq('player_index', playerIndex);

        if (error) throw new Error(`Failed to clear duo slot for ${teamName}: ${error.message}`);
    }

    // Pure history log now - substitutions no longer determines who's
    // currently playing (duos does), this just records that a change happened.
    // Never throws - a failed log entry shouldn't take down the actual change.
    // IMPORTANT: updateAllScores still resolves "who was playing" for past
    // weeks by searching this table for an entry with end_week IS NULL - see
    // the matching note in update-standings.js. That lookup is only reliable
    // if at most one such entry ever exists per team/award/player_index at a
    // time, regardless of whether it was the owner or the automation that
    // wrote it last. So every write here closes out any prior open entry for
    // this exact slot FIRST, mirroring the same close-out set-duo does on
    // its own writes - the two paths have to agree on this or the same
    // ambiguity bug reappears from whichever direction wasn't covered.
    async logSubstitution({ teamName, awardType, playerIndex, originalName, originalPosition, substituteName, substitutePlayerId, substitutePosition, week, source, reason, noReplacementAvailable }) {
        const teamId = this.teamIdByName[teamName];
        if (!teamId) {
            console.warn(`Skipping substitution log - unknown team: ${teamName}`);
            return;
        }

        const { error: closeOutError } = await this.supabase
            .from('substitutions')
            .update({ end_week: Math.max(0, week - 1), active: false })
            .eq('team_id', teamId)
            .eq('award_type', awardType)
            .eq('player_index', playerIndex)
            .is('end_week', null);
        if (closeOutError) {
            console.error(`Failed to close out prior substitution entries (non-fatal): ${closeOutError.message}`);
        }

        const { error } = await this.supabase.from('substitutions').insert({
            team_id: teamId,
            award_type: awardType,
            player_index: playerIndex,
            original_name: originalName,
            original_position: originalPosition,
            substitute_name: substituteName,
            substitute_player_id: substitutePlayerId,
            substitute_position: substitutePosition,
            start_week: week,
            end_week: null,
            active: true,
            source,
            reason,
            no_replacement_available: noReplacementAvailable || false
        });

        if (error) console.error(`Failed to log substitution (non-fatal): ${error.message}`);
    }

    // Returns substitutions in the same shape the automation has always used internally,
    // with an extra _id field (used to know which rows to UPDATE vs INSERT on save).
    async loadSubstitutions() {
        const { data, error } = await this.supabase
            .from('substitutions')
            .select('*')
            .in('team_id', Object.values(this.teamIdByName));

        if (error) throw new Error(`Failed to load substitutions: ${error.message}`);

        return data.map(row => ({
            _id: row.id,
            teamName: this.teamNameById[row.team_id],
            playerIndex: row.player_index,
            awardType: row.award_type,
            originalName: row.original_name,
            originalPosition: row.original_position,
            substituteName: row.substitute_name,
            substitutePlayerId: row.substitute_player_id,
            substitutePosition: row.substitute_position,
            startWeek: row.start_week,
            endWeek: row.end_week,
            active: row.active,
            autoGenerated: row.source === 'auto',
            reason: row.reason,
            noReplacementAvailable: row.no_replacement_available,
            isTemporaryByeReplacement: row.reason?.includes('Temporary Bye Week Replacement') || false
        }));
    }

    // Splits on presence of _id: existing rows (possibly mutated, e.g. endWeek closed
    // out) get updated in place; brand new substitution objects get inserted.
    async saveSubstitutions(substitutions) {
        const updates = substitutions.filter(s => s._id);
        const inserts = substitutions.filter(s => !s._id);

        for (const s of updates) {
            const { error } = await this.supabase
                .from('substitutions')
                .update({ end_week: s.endWeek, active: s.endWeek ? false : s.active })
                .eq('id', s._id);
            if (error) throw new Error(`Failed to update substitution ${s._id}: ${error.message}`);
        }

        if (inserts.length > 0) {
            const rows = inserts.map(s => ({
                team_id: this.teamIdByName[s.teamName],
                award_type: s.awardType,
                player_index: s.playerIndex,
                original_name: s.originalName,
                original_position: s.originalPosition,
                substitute_name: s.substituteName,
                substitute_player_id: s.substitutePlayerId,
                substitute_position: s.substitutePosition,
                start_week: s.startWeek,
                end_week: s.endWeek,
                active: s.active,
                source: s.autoGenerated === false ? 'owner' : 'auto',
                reason: s.reason,
                no_replacement_available: s.noReplacementAvailable || false
            })).filter(r => r.team_id); // drop rows for unknown teams rather than error the whole batch

            const { error } = await this.supabase.from('substitutions').insert(rows);
            if (error) throw new Error(`Failed to insert substitutions: ${error.message}`);
        }
    }

    // Persists one week's NFL schedule (opponent, kickoff time, bye status
    // per team) so the frontend can show "next game" info directly from
    // Supabase, without ever calling ESPN's API itself. Upserted on the
    // team/week unique constraint, so a re-fetch (flex move, weather
    // reschedule) simply overwrites the stale row rather than creating a
    // duplicate.
    async saveNFLSchedule(week, schedule) {
        if (!schedule) return; // fetchNFLSchedule returns null on a failed fetch - nothing to save
        const rows = Object.entries(schedule).map(([team, info]) => ({
            season_id: this.seasonId,
            week,
            nfl_team: team,
            opponent_nfl_team: info.opponent || null,
            kickoff_time: info.date ? info.date.toISOString() : null,
            is_bye: info.date === null,
            updated_at: new Date().toISOString()
        }));

        const { error } = await this.supabase
            .from('nfl_schedule')
            .upsert(rows, { onConflict: 'season_id,week,nfl_team' });

        if (error) console.error(`Failed to save NFL schedule for week ${week}:`, error.message);
    }

    // Upserted on RotoWire's own item guid, so the same story is never
    // duplicated across repeated automation runs - see 025-player-news.sql.
    // sleeperPlayerId may be null (name didn't match any known Sleeper
    // player) - still stored rather than dropped, just never surfaced
    // anywhere that requires a player match.
    // Minimal-field read of every player_news row, for re-validating
    // already-saved items against the CURRENT filter rules in
    // update-standings.js (see pruneDisqualifiedNews). Filter rules can
    // change after items were already saved under looser rules - this is
    // what lets a filter change clean up its own past output rather than
    // only affecting saves from that point forward.
    // Supabase's REST API silently caps any .select() with no explicit
    // range at 1000 rows - confirmed directly as the cause of a real bug:
    // pruneDisqualifiedNews only ever checked the first 1000 rows
    // returned, never the full table, so most of a many-thousand-row
    // table was simply invisible to it. Pages through in batches of 1000
    // until a page comes back short (the real end of the table), rather
    // than relying on any single request to return everything.
    async loadAllPlayerNewsForPruning() {
        const PAGE_SIZE = 1000;
        const allRows = [];
        let from = 0;

        while (true) {
            const { data, error } = await this.supabase
                .from('player_news')
                .select('id, rotowire_guid, headline, source_name, sleeper_player_id, player_name')
                .range(from, from + PAGE_SIZE - 1);

            if (error) {
                console.error('Failed to load player_news for pruning:', error.message);
                break;
            }
            if (!data || data.length === 0) break;

            allRows.push(...data);
            if (data.length < PAGE_SIZE) break; // short page = end of table
            from += PAGE_SIZE;
        }

        return allRows;
    }

    // Chunked rather than one .in() call with the full id list - confirmed
    // directly as a real production failure: a single request with ~839
    // UUIDs encodes as an enormous URL (.in() filters are built into the
    // request URL as query params) and Supabase rejects it outright with
    // "Bad Request". That failure was silent to the pruning logic itself
    // (it correctly identified every disqualified row every run - the
    // delete request was what failed), which is why the exact same
    // articles kept reappearing across multiple runs despite the
    // identification working correctly every time. Small chunks avoid
    // the URL-length ceiling entirely; one chunk failing is logged and
    // does not block the rest from being attempted.
    async deletePlayerNewsByIds(ids) {
        if (!ids || ids.length === 0) return;

        const CHUNK_SIZE = 100;
        let deleted = 0;
        for (let i = 0; i < ids.length; i += CHUNK_SIZE) {
            const chunk = ids.slice(i, i + CHUNK_SIZE);
            const { error } = await this.supabase
                .from('player_news')
                .delete()
                .in('id', chunk);

            if (error) {
                console.error(`Failed to delete a chunk of disqualified player_news rows (${chunk.length} ids): ${error.message}`);
            } else {
                deleted += chunk.length;
            }
        }
        return deleted;
    }

    async savePlayerNews(items) {
        if (!items || items.length === 0) return;
        const rows = items.map(item => ({
            rotowire_guid: item.rotowireGuid,
            sleeper_player_id: item.sleeperPlayerId || null,
            player_name: item.playerName,
            headline: item.headline,
            snippet: item.snippet,
            source_url: item.sourceUrl,
            source_name: item.sourceName || null,
            published_at: item.publishedAt.toISOString(),
            fetched_at: new Date().toISOString()
        }));

        const { error } = await this.supabase
            .from('player_news')
            .upsert(rows, { onConflict: 'rotowire_guid' });

        if (error) console.error('Failed to save player news:', error.message);
    }

    // Learns a Sleeper player's RotoWire profile URL, discovered
    // opportunistically whenever they appear in RotoWire's shared feed -
    // see 026-rotowire-player-links.sql. Never overwrites an existing
    // mapping (a player's RotoWire URL doesn't change), so this is a
    // pure insert-if-missing rather than an upsert.
    async saveRotowirePlayerLinks(items) {
        if (!items || items.length === 0) return;

        const { data: existing, error: fetchError } = await this.supabase
            .from('rotowire_player_links')
            .select('sleeper_player_id')
            .in('sleeper_player_id', items.map(i => i.sleeperPlayerId));

        if (fetchError) {
            console.error('Failed to check existing RotoWire player links:', fetchError.message);
            return;
        }

        const alreadyKnown = new Set((existing || []).map(r => r.sleeper_player_id));
        const newRows = items
            .filter(i => !alreadyKnown.has(i.sleeperPlayerId))
            // If the same player appears twice in one fetch, only keep one row
            .filter((i, idx, arr) => arr.findIndex(x => x.sleeperPlayerId === i.sleeperPlayerId) === idx)
            .map(i => ({ sleeper_player_id: i.sleeperPlayerId, rotowire_url: i.rotowireUrl }));

        if (newRows.length === 0) return;

        const { error: insertError } = await this.supabase
            .from('rotowire_player_links')
            .insert(newRows);

        if (insertError) console.error('Failed to save new RotoWire player links:', insertError.message);
        else console.log(`Learned ${newRows.length} new RotoWire player URL(s)`);
    }

    async getRotowirePlayerLinks(sleeperPlayerIds) {
        if (!sleeperPlayerIds || sleeperPlayerIds.length === 0) return [];

        const { data, error } = await this.supabase
            .from('rotowire_player_links')
            .select('sleeper_player_id, rotowire_url')
            .in('sleeper_player_id', sleeperPlayerIds);

        if (error) {
            console.error('Failed to load RotoWire player links:', error.message);
            return [];
        }

        return (data || []).map(r => ({ sleeperPlayerId: r.sleeper_player_id, rotowireUrl: r.rotowire_url }));
    }

    // scores/playerIds shape: { [awardType]: { [teamName]: { [week]: { [index]: value } } } }
    // (this matches updateAllScores()'s existing internal structure - see update-standings.js)
    async saveWeeklyScores(scores, playerIds, playersData, wasBye) {
        const rows = [];
        for (const awardType of ['main', 'nextup', 'boom']) {
            for (const [teamName, byWeek] of Object.entries(scores[awardType] || {})) {
                const teamId = this.teamIdByName[teamName];
                if (!teamId) continue;

                for (const [week, byIndex] of Object.entries(byWeek)) {
                    for (const [index, points] of Object.entries(byIndex)) {
                        const sleeperPlayerId = playerIds?.[awardType]?.[teamName]?.[week]?.[index];
                        if (!sleeperPlayerId) continue; // nothing to key the row on

                        // Captured at write time, not resolved later from duos, so
                        // past weeks stay accurate even after a player is swapped.
                        const player = playersData?.[sleeperPlayerId];
                        const playerName = player ? `${player.first_name || ''} ${player.last_name || ''}`.trim() : null;

                        rows.push({
                            team_id: teamId,
                            award_type: awardType,
                            week: Number(week),
                            sleeper_player_id: sleeperPlayerId,
                            points: points || 0,
                            player_name: playerName || null,
                            player_position: player?.position || null,
                            was_bye: !!wasBye?.[awardType]?.[teamName]?.[week]?.[index],
                            player_index: Number(index)
                        });
                    }
                }
            }
        }

        if (rows.length === 0) return;

        const { error } = await this.supabase
            .from('weekly_scores')
            // Keyed on the SLOT itself (team_id, award_type, week,
            // player_index), not on sleeper_player_id - there is always
            // exactly one real answer to "who was credited for this slot
            // in this week," and a changed player must REPLACE any
            // existing row for that same slot/week, never accumulate
            // alongside it. Confirmed as a real, live bug: the previous
            // key (including sleeper_player_id) let an admin correction's
            // new player sit alongside the old one's now-orphaned row,
            // showing 3 players for a 2-player award. See
            // 030-weekly-scores-key-on-slot.sql.
            .upsert(rows, { onConflict: 'team_id,award_type,week,player_index' });

        if (error) throw new Error(`Failed to save weekly scores: ${error.message}`);
    }

    // Brown Bell weekly bonus matchup results - one row per team per week
    // (a matchup between A and B produces 2 rows, one from each side).
    // resultsByTeamName: { teamName: { opponent, teamScore, opponentScore, outcome, tier, bonusPoints } }
    async saveBonusResults(week, resultsByTeamName, isFinalByTeamName = {}, outcomeFinalByTeamName = {}) {
        const rows = [];
        for (const [teamName, result] of Object.entries(resultsByTeamName)) {
            const teamId = this.teamIdByName[teamName];
            if (!teamId) continue;
            const opponentId = result.opponent ? this.teamIdByName[result.opponent] : null;

            rows.push({
                team_id: teamId,
                week,
                opponent_team_id: opponentId || null,
                team_score: result.teamScore,
                opponent_score: result.opponentScore,
                outcome: result.outcome,
                tier: result.tier,
                bonus_points: result.bonusPoints,
                // Whether the TIER/BONUS AMOUNT is stable - genuinely
                // requires the whole week's matchups to be done, since
                // tiers rank all of them against each other in one shared
                // sort (see the comment in update-standings.js).
                is_final: !!isFinalByTeamName[teamName],
                // Whether THIS SPECIFIC matchup's winner is already
                // decided - independent of the rest of the week. Added
                // after a real reported case where the season-long W-L-T
                // record was incorrectly forced to wait on the whole
                // week's single slowest matchup, when a matchup's own
                // outcome is already genuinely known as soon as its own 4
                // players are done.
                outcome_final: !!outcomeFinalByTeamName[teamName]
            });
        }

        if (rows.length === 0) return;

        // Detect stat corrections: if a row already exists AND was already
        // final AND the numbers about to be written actually differ, that's
        // Sleeper correcting something after the fact (commonly settled the
        // Tuesday after Monday Night Football, but this catches it whenever
        // it actually happens) - snapshot the before/after BEFORE
        // overwriting, so the change is visible rather than silently lost.
        const teamIds = rows.map(r => r.team_id);
        const { data: existingRows, error: existingError } = await this.supabase
            .from('bonus_results')
            .select('team_id, team_score, outcome, tier, bonus_points, is_final')
            .eq('week', week)
            .in('team_id', teamIds);

        if (existingError) {
            console.error(`Failed to check for stat corrections (non-fatal, proceeding with write): ${existingError.message}`);
        } else {
            const existingByTeamId = new Map((existingRows || []).map(r => [r.team_id, r]));
            const corrections = [];

            for (const row of rows) {
                const existing = existingByTeamId.get(row.team_id);
                if (!existing || !existing.is_final) continue; // nothing to compare, or wasn't final yet - not a correction

                const changed = Number(existing.team_score) !== Number(row.team_score) ||
                    existing.outcome !== row.outcome ||
                    existing.tier !== row.tier ||
                    Number(existing.bonus_points) !== Number(row.bonus_points);

                if (changed) {
                    corrections.push({
                        team_id: row.team_id,
                        week,
                        original_team_score: existing.team_score,
                        corrected_team_score: row.team_score,
                        original_outcome: existing.outcome,
                        corrected_outcome: row.outcome,
                        original_tier: existing.tier,
                        corrected_tier: row.tier,
                        original_bonus_points: existing.bonus_points,
                        corrected_bonus_points: row.bonus_points
                    });
                }
            }

            if (corrections.length > 0) {
                console.warn(`Detected ${corrections.length} stat correction(s) for week ${week} - logging before overwriting`);
                const { error: correctionError } = await this.supabase.from('bonus_result_corrections').insert(corrections);
                if (correctionError) {
                    console.error(`Failed to log stat correction(s) (non-fatal, proceeding with write): ${correctionError.message}`);
                }
            }
        }

        const { error } = await this.supabase
            .from('bonus_results')
            .upsert(rows, { onConflict: 'team_id,week' });

        if (error) throw new Error(`Failed to save bonus results: ${error.message}`);
    }

    // Companion to saveBonusResults - removes any bonus_results rows for a
    // week that turns out to have no real score data. Needed because a
    // week's bonus results might already have been (incorrectly) written by
    // an earlier run before this check existed, or before Sleeper had
    // posted any stats yet - this cleans that up on the next run rather
    // than leaving stale "everyone tied 0-0" results sitting there.
    async clearBonusResultsForWeek(week) {
        const { error } = await this.supabase.from('bonus_results').delete().eq('week', week);
        if (error) console.error(`Failed to clear stale bonus results for week ${week} (non-fatal): ${error.message}`);
    }

    // Every prediction vote cast for a given week, keyed by team NAME (not
    // team_id) via the reverse of this.teamIdByName - the recap's whole
    // content blob is built and stored in terms of team names throughout,
    // since it's a static, read-only snapshot with no need to reference
    // live team rows at all once written.
    async getMatchupPredictionsForWeek(week) {
        const teamNameById = Object.fromEntries(Object.entries(this.teamIdByName).map(([name, id]) => [id, name]));

        const { data, error } = await this.supabase
            .from('matchup_predictions')
            .select('team_a_id, team_b_id, predicted_winner_team_id')
            .eq('week', week);

        if (error) {
            console.error(`Failed to fetch predictions for week ${week} (non-fatal, recap will omit this section): ${error.message}`);
            return [];
        }

        return (data || [])
            .map(row => ({
                teamAName: teamNameById[row.team_a_id],
                teamBName: teamNameById[row.team_b_id],
                predictedWinnerName: teamNameById[row.predicted_winner_team_id]
            }))
            .filter(row => row.teamAName && row.teamBName && row.predictedWinnerName);
    }

    // Every team's accumulated Main Award bonus points through (and
    // including) a given week, counting only rows that were already
    // marked is_final - matches the same rule the frontend's season
    // standings use (a team's tier/bonus amount isn't genuinely stable
    // until its whole week is done), so the recap's standings snapshot
    // can't disagree with what the League tab itself shows for the same
    // week. Keyed by team NAME, same reasoning as getMatchupPredictionsForWeek.
    //
    // Deliberately does NOT include prediction-poll bonus points, unlike
    // the frontend's "combined" ranking - porting the 4-week block
    // logic here was judged out of scope for now. This can only actually
    // diverge from the frontend starting the week a block first
    // completes (every 4th week) - revisit before then if this recap
    // feature is still in use at that point.
    async getBonusTotalsThroughWeek(week) {
        const teamNameById = Object.fromEntries(Object.entries(this.teamIdByName).map(([name, id]) => [id, name]));

        const { data, error } = await this.supabase
            .from('bonus_results')
            .select('team_id, bonus_points')
            .eq('is_final', true)
            .lte('week', week);

        if (error) {
            console.error(`Failed to fetch bonus totals through week ${week} (non-fatal, recap standings will show season points only): ${error.message}`);
            return {};
        }

        const totals = {};
        for (const row of data || []) {
            const teamName = teamNameById[row.team_id];
            if (!teamName) continue;
            totals[teamName] = (totals[teamName] || 0) + Number(row.bonus_points);
        }
        return totals;
    }

    // Inserts a week's recap content ONLY if one doesn't already exist -
    // deliberately not an upsert. A link someone has already been given
    // shouldn't change under them later if, say, a stat correction comes
    // in after the fact; a genuine need to regenerate one is a separate,
    // manual action, not a side effect of a routine automation run.
    async saveWeeklyRecapIfNotExists(week, content) {
        const { data: existing, error: checkError } = await this.supabase
            .from('weekly_recaps')
            .select('week')
            .eq('week', week)
            .maybeSingle();

        if (checkError) {
            console.error(`Failed to check for existing recap for week ${week} (non-fatal, skipping recap generation this run): ${checkError.message}`);
            return;
        }
        if (existing) return; // already generated - never silently overwrite

        const { error: insertError } = await this.supabase
            .from('weekly_recaps')
            .insert({ week, content });

        if (insertError) {
            console.error(`Failed to save weekly recap for week ${week} (non-fatal): ${insertError.message}`);
        } else {
            console.log(`📰 Generated weekly recap for week ${week}`);
        }
    }

    // Every substitution that took effect starting a specific week, for a
    // given award - used by the recap's "Critical Sub of the Week"
    // category, which needs to know not just THAT a sub happened but
    // exactly which team/slot it landed in, so the recap can look up how
    // that substitute actually performed that week.
    async getSubstitutionsStartingWeek(week, awardType) {
        const teamNameById = Object.fromEntries(Object.entries(this.teamIdByName).map(([name, id]) => [id, name]));

        const { data, error } = await this.supabase
            .from('substitutions')
            .select('team_id, player_index, original_name, substitute_name, substitute_position, substitute_player_id, source')
            .eq('award_type', awardType)
            .eq('start_week', week);

        if (error) {
            console.error(`Failed to fetch substitutions for week ${week} (non-fatal, recap will omit Critical Sub): ${error.message}`);
            return [];
        }

        return (data || [])
            .map(row => ({ ...row, teamName: teamNameById[row.team_id] }))
            .filter(row => row.teamName && row.substitute_player_id);
    }

    // Every substitution that was ACTIVE during a specific week - not just
    // ones that started that week (see getSubstitutionsStartingWeek above,
    // used only for Critical Sub of the Week). This is broader: a sub that
    // started week 1 and is still in place during week 3 should still
    // label that player as a sub in week 3's recap, not just week 1's.
    // Used so every player shown anywhere in the recap (matchups,
    // standings) can be correctly labeled, matching a real owner request
    // to see who subbed in and for whom directly in the recap, not just
    // via the single best-performing sub that Critical Sub already shows.
    async getActiveSubstitutionsForWeek(week, awardType) {
        const teamNameById = Object.fromEntries(Object.entries(this.teamIdByName).map(([name, id]) => [id, name]));

        const { data, error } = await this.supabase
            .from('substitutions')
            .select('team_id, player_index, original_name, substitute_name, source, end_week')
            .eq('award_type', awardType)
            .lte('start_week', week);

        if (error) {
            console.error(`Failed to fetch active substitutions for week ${week} (non-fatal, recap will omit sub labels): ${error.message}`);
            return [];
        }

        // end_week null means still active/ongoing - filtered client-side
        // rather than in the query, since "null OR >= week" isn't a single
        // clean .lte()/.gte() chain against a nullable column.
        return (data || [])
            .filter(row => row.end_week === null || row.end_week === undefined || row.end_week >= week)
            .map(row => ({ ...row, teamName: teamNameById[row.team_id] }))
            .filter(row => row.teamName);
    }

    async loadRosterChanges() {
        const { data, error } = await this.supabase
            .from('roster_changes')
            .select('team_id, award_type, player_index, change_week, reason')
            .in('team_id', Object.values(this.teamIdByName));
        if (error) throw new Error(`Failed to load roster changes: ${error.message}`);
        return data.map(r => ({
            teamName: this.teamNameById[r.team_id],
            awardType: r.award_type,
            playerIndex: r.player_index,
            changeWeek: r.change_week,
            reason: r.reason
        }));
    }

    async loadManagerChanges() {
        const { data, error } = await this.supabase
            .from('manager_changes')
            .select('team_id, previous_manager, change_week, reason')
            .in('team_id', Object.values(this.teamIdByName));
        if (error) throw new Error(`Failed to load manager changes: ${error.message}`);

        const result = {};
        for (const r of data) {
            const teamName = this.teamNameById[r.team_id];
            if (teamName) result[teamName] = { previousManager: r.previous_manager, changeWeek: r.change_week, reason: r.reason };
        }
        return result;
    }

    async loadScheduleSnapshot(week) {
        const { data, error } = await this.supabase
            .from('schedule_snapshots')
            .select('teams, captured_at')
            .eq('season_id', this.seasonId)
            .eq('week', week)
            .maybeSingle();
        if (error) throw new Error(`Failed to load schedule snapshot: ${error.message}`);
        return data ? { teams: data.teams, capturedAt: data.captured_at } : null;
    }

    async saveScheduleSnapshot(week, teams, capturedAt) {
        const { error } = await this.supabase
            .from('schedule_snapshots')
            .upsert({ season_id: this.seasonId, week, teams, captured_at: capturedAt }, { onConflict: 'season_id,week' });
        if (error) throw new Error(`Failed to save schedule snapshot: ${error.message}`);
    }

    async loadScheduleChanges(week) {
        const { data, error } = await this.supabase
            .from('schedule_changes')
            .select('changes')
            .eq('season_id', this.seasonId)
            .eq('week', week)
            .order('detected_at', { ascending: false })
            .limit(1)
            .maybeSingle();
        if (error) throw new Error(`Failed to load schedule changes: ${error.message}`);
        return data ? data.changes : [];
    }

    async saveScheduleChanges(week, changes) {
        if (!changes || changes.length === 0) return;
        const { error } = await this.supabase
            .from('schedule_changes')
            .insert({ season_id: this.seasonId, week, changes });
        if (error) throw new Error(`Failed to save schedule changes: ${error.message}`);
    }
}

module.exports = SupabaseDataLayer;
